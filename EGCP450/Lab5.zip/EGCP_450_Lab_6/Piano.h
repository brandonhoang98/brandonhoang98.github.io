/*
 * Piano.h
 *
 *  Created on: Oct 28, 2019
 *      Author: ee-student
 */

#ifndef PIANO_H_
#define PIANO_H_

void Piano_init(void);
long Piano_in(void);



#endif /* PIANO_H_ */
