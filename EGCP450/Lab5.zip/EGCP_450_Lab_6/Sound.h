#ifndef SOUND_H_
#define SOUND_H_

void Sound_init(void);
void Sound_play(uint32_t);

#endif