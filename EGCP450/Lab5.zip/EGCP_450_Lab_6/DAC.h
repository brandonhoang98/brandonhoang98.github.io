/*
 * DAC.h
 *
 *  Created on: Oct 23, 2019
 *      Author: ee-student
 */



void DAC_init();
void DAC_output(unsigned long data);

 /* DAC_H_ */
